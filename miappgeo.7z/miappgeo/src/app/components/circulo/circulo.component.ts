import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-circulo',
  standalone: true,
  imports: [IonicModule, FormsModule, CommonModule],
  template: `
    <ion-card>
      <ion-card-header>
        <ion-card-title>Perímetro del Círculo</ion-card-title>
      </ion-card-header>
      <ion-card-content>
        <ion-item>
          <ion-label position="floating">Radio</ion-label>
          <ion-input [(ngModel)]="radio" type="number"></ion-input>
        </ion-item>
        <ion-button expand="block" (click)="calcularPerimetro()">Calcular Perímetro</ion-button>
        <p *ngIf="resultado !== null">Resultado: {{ resultado | number: '1.2-2' }}</p>
        <ion-img src="assets/circulo.png" alt="Imagen círculo"></ion-img>
      </ion-card-content>
    </ion-card>
  `
})
export class CirculoComponent {
  radio = 0;
  resultado: number | null = null;

  calcularPerimetro() {
    this.resultado = 2 * Math.PI * this.radio;
  }
}
