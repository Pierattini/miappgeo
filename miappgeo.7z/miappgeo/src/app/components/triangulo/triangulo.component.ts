import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-triangulo',
  standalone: true,
  imports: [IonicModule, FormsModule, CommonModule],
  template: `
    <ion-card>
      <ion-card-header>
        <ion-card-title>Perímetro del Triángulo Escaleno</ion-card-title>
      </ion-card-header>
      <ion-card-content>
        <ion-item>
          <ion-label position="floating">Lado A</ion-label>
          <ion-input [(ngModel)]="ladoA" type="number"></ion-input>
        </ion-item>
        <ion-item>
          <ion-label position="floating">Lado B</ion-label>
          <ion-input [(ngModel)]="ladoB" type="number"></ion-input>
        </ion-item>
        <ion-item>
          <ion-label position="floating">Lado C</ion-label>
          <ion-input [(ngModel)]="ladoC" type="number"></ion-input>
        </ion-item>
        <ion-button expand="block" (click)="calcularPerimetro()">Calcular Perímetro</ion-button>
        <p *ngIf="resultado !== null">Resultado: {{ resultado | number: '1.2-2' }}</p>
        <ion-img src="assets/triangulo.png" alt="Imagen triángulo"></ion-img>
      </ion-card-content>
    </ion-card>
  `
})
export class TrianguloComponent {
  ladoA = 0;
  ladoB = 0;
  ladoC = 0;
  resultado: number | null = null;

  calcularPerimetro() {
    this.resultado = this.ladoA + this.ladoB + this.ladoC;
  }
}
