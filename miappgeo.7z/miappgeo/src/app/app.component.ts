import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { CirculoComponent } from './components/circulo/circulo.component';
import { TrianguloComponent } from './components/triangulo/triangulo.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    IonicModule,
    FormsModule,
    CommonModule,
    CirculoComponent,
    TrianguloComponent
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'miappgeo';
  figuraSeleccionada: string | null = null;

  circuloComp = CirculoComponent;
  trianguloComp = TrianguloComponent;
}
