export abstract class FiguraGeometrica {
    abstract calcularPerimetro(): number;
  }
  