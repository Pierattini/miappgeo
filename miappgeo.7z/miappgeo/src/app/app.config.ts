import { provideIonicAngular } from '@ionic/angular/standalone';

export const appConfig = {
  providers: [
    provideIonicAngular()
  ]
};
